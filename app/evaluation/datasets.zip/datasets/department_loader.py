import json
from .formatters import normalize_text


def load_department_dataset(path, max_samples=None):
    """
    Loads a department dataset in JSONL format and unifies into:
    { "input": str, "target": str }
    """
    items = []

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            obj = json.loads(line)

            # Support multiple formats
            inp = (
                obj.get("instruction")
                or obj.get("prompt")
                or obj.get("input")
            )
            out = obj.get("output") or obj.get("response")

            if not inp or not out:
                continue

            items.append({
                "input": normalize_text(inp),
                "target": normalize_text(out)
            })

            if max_samples and len(items) >= max_samples:
                break

    return items
